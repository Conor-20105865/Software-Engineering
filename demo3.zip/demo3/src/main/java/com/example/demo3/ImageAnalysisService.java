package com.example.demo3;

public class ImageAnalysisService {

    public String extractTextFromImage(String imageData) {
        // Mock image text extraction logic
        if (imageData == null || imageData.isEmpty()) {
            return "";
        }
        return "Extracted text from image";
    }
}

